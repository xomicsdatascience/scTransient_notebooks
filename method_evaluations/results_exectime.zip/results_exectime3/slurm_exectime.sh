#!/usr/bin/env bash
#SBATCH --job-name=exectime
#SBATCH --output=logs_exectime3/%x_%A_%a.out
#SBATCH --error=logs_exectime3/%x_%A_%a.err
#SBATCH --array=0-749
#SBATCH --time=6:00:00
#SBATCH --partition=defq
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=16G

# Create log directory if not exists
idx="exectime3"
outdir="results_${idx}"
paramfile="${outdir}/params.py"
mkdir -p logs
mkdir -p ${outdir}


# Load required modules (placeholders)
module load singularity-apptainer/1.1.6

# Echo basic context
echo "Job ID: ${SLURM_JOB_ID}"
echo "Array Task ID: ${SLURM_ARRAY_TASK_ID}"
echo "Host: $(hostname)"
echo "Started at: $(date)"

#if [[ ${SLURM_ARRAY_TASK_ID} == 0 ]]; then
#  cp ${paramfile} ${outdir}/
#fi


# Placeholders for your commands
# 1) Example: run a Python script with task-specific input
# python your_script.py --index "${SLURM_ARRAY_TASK_ID}" --input "inputs/file_${SLURM_ARRAY_TASK_ID}.txt"
singularity exec method_evaluations/method_eval_2.sif python3.11 method_evaluations/method_execution.py --index ${SLURM_ARRAY_TASK_ID} --output_dir ${outdir} --parameter_file ${paramfile}

echo "Finished at: $(date)"
