import numpy as np


def